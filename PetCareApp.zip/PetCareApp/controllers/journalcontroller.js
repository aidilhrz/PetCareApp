const Pet = require('../models/petModel');
const Journal = require('../models/journalModel');

async function listJournals(req, res) {
  const userId = req.session.user.id;
  let selectedPetId = req.query.petId;

  try {
    const pets = await Pet.findByOwner(userId);
    if (!selectedPetId && pets.length > 0) selectedPetId = pets[0].id;

    if (!selectedPetId) {
      return res.render('journals', {
        journals: [],
        pets,
        selectedPetId: '',
        pet: null,
        session: req.session,
        messages: req.flash('success'),
        errors: req.flash('error'),
        warnings: req.flash('warning')
      });
    }

    const pet = pets.find(item => item.id.toString() === selectedPetId.toString());
    if (!pet) return res.status(404).send('Pet not found');

    const journals = await Journal.findByOwnerAndPet(userId, selectedPetId);
    res.render('journals', {
      journals,
      pets,
      selectedPetId,
      pet,
      session: req.session,
      messages: req.flash('success'),
      errors: req.flash('error'),
      warnings: req.flash('warning')
    });
  } catch (error) {
    console.error('Error loading journals:', error);
    res.status(500).send('Error loading journals');
  }
}

async function showNewJournal(req, res) {
  try {
    const pets = await Pet.findByOwner(req.session.user.id);
    res.render('newJournal', {
      pets,
      session: req.session,
      selectedPetId: req.query.petId
    });
  } catch (error) {
    console.error('Error loading pets for journal form:', error);
    res.status(500).send('Error loading pets');
  }
}

async function createJournal(req, res) {
  const { pet_id, activity, notes, entry_date } = req.body;

  try {
    const created = await Journal.createForOwner(req.session.user.id, {
      petId: pet_id,
      activity,
      notes,
      entryDate: entry_date
    });
    if (!created) return res.status(404).send('Pet not found');
    res.redirect(`/journals?petId=${encodeURIComponent(pet_id)}`);
  } catch (error) {
    console.error('Error saving journal:', error);
    res.status(500).send('Error saving journal');
  }
}

async function showEditJournal(req, res) {
  try {
    const [journal, pets] = await Promise.all([
      Journal.findByIdForOwner(req.params.id, req.session.user.id),
      Pet.findByOwner(req.session.user.id)
    ]);

    if (!journal) return res.status(404).send('Journal not found');
    res.render('editJournal', { journal, pets, session: req.session });
  } catch (error) {
    console.error('Error loading journal for editing:', error);
    res.status(500).send('Error fetching journal');
  }
}

async function updateJournal(req, res) {
  const { entry_date, activity, notes, pet_id } = req.body;

  try {
    const updated = await Journal.updateForOwner(req.session.user.id, req.params.id, {
      petId: pet_id,
      entryDate: entry_date,
      activity,
      notes
    });
    if (!updated) return res.status(404).send('Journal or pet not found');
    res.redirect(`/journals?petId=${encodeURIComponent(pet_id)}`);
  } catch (error) {
    console.error('Error updating journal:', error);
    res.status(500).send('Error updating journal');
  }
}

async function deleteJournal(req, res) {
  try {
    const journal = await Journal.findByIdForOwner(req.params.id, req.session.user.id);
    if (!journal) return res.status(404).send('Journal not found.');

    await Journal.deleteForOwner(req.session.user.id, req.params.id);
    res.redirect(`/journals?petId=${encodeURIComponent(journal.pet_id)}`);
  } catch (error) {
    console.error('Error deleting journal:', error);
    res.status(500).send('Error deleting journal.');
  }
}

async function searchJournals(req, res) {
  const userId = req.session.user.id;
  const selectedPetId = req.query.petId;
  const query = `%${req.query.q || ''}%`;

  try {
    const pets = await Pet.findByOwner(userId);
    let pet = null;
    if (selectedPetId) {
      pet = pets.find(item => item.id.toString() === selectedPetId.toString()) || null;
      if (!pet) return res.status(404).send('Pet not found');
    }

    const journals = await Journal.searchForOwner(userId, query, selectedPetId);
    res.render('journals', {
      journals,
      pets,
      selectedPetId,
      pet,
      session: req.session,
      messages: req.flash('success'),
      errors: req.flash('error'),
      warnings: req.flash('warning')
    });
  } catch (error) {
    console.error('Error searching journals:', error);
    res.status(500).send('Error searching journals');
  }
}

module.exports = {
  listJournals,
  showNewJournal,
  createJournal,
  showEditJournal,
  updateJournal,
  deleteJournal,
  searchJournals
};
