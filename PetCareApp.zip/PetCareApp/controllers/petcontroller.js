const Pet = require('../models/petModel');
const { validatePet } = require('../helpers/petValidation');
const { deleteImageIfUnused } = require('../helpers/petImageHelper');

function showNewPet(req, res) {
  res.render('newPet', {
    session: req.session,
    errors: [],
    form: {},
    errorsFromFlash: req.flash('error'),
    messages: req.flash('success'),
    warnings: req.flash('warning')
  });
}

async function createPet(req, res) {
  const { values, errors } = validatePet(req.body);

  if (errors.length > 0) {
    if (req.file) {
      try {
        await deleteImageIfUnused(req.file.filename);
      } catch (error) {
        console.error('Unable to remove rejected pet image:', error);
      }
    }
    return res.status(400).render('newPet', {
      session: req.session,
      errors,
      form: values
    });
  }

  try {
    await Pet.create({
      ownerId: req.session.user.id,
      ...values,
      image: req.file ? req.file.filename : null
    });
    req.flash('success', `${values.name} has been added to your pets.`);
    return res.redirect('/journals');
  } catch (error) {
    console.error('Error adding pet:', error);
    if (req.file) {
      try {
        await deleteImageIfUnused(req.file.filename);
      } catch (cleanupError) {
        console.error('Unable to remove pet image after creation failed:', cleanupError);
      }
    }
    req.flash('error', 'We could not add this pet right now. Please try again.');
    return res.redirect('/pets/new');
  }
}

function showEditPet(req, res) {
  res.render('editPet', {
    session: req.session,
    pet: req.pet,
    errors: [],
    errorsFromFlash: req.flash('error'),
    messages: req.flash('success'),
    warnings: req.flash('warning')
  });
}

async function updatePet(req, res) {
  const { values, errors } = validatePet(req.body);
  const pet = req.pet;

  if (errors.length > 0) {
    if (req.file) {
      try {
        await deleteImageIfUnused(req.file.filename);
      } catch (error) {
        console.error('Unable to remove rejected replacement pet image:', error);
      }
    }
    return res.status(400).render('editPet', {
      session: req.session,
      pet: { ...pet, ...values },
      errors
    });
  }

  const image = req.file ? req.file.filename : pet.image;
  try {
    const updated = await Pet.updateForOwner(pet.id, req.session.user.id, {
      ...values,
      image
    });
    if (!updated) {
      if (req.file) await deleteImageIfUnused(req.file.filename);
      return res.status(404).send('Pet not found.');
    }
  } catch (error) {
    console.error('Error updating pet:', error);
    if (req.file) {
      try {
        await deleteImageIfUnused(req.file.filename);
      } catch (cleanupError) {
        console.error('Unable to remove replacement pet image after update failed:', cleanupError);
      }
    }
    req.flash('error', 'We could not update this pet right now. Please try again.');
    return res.redirect(`/pets/${pet.id}/edit`);
  }

  if (req.file && pet.image && pet.image !== image) {
    try {
      await deleteImageIfUnused(pet.image);
    } catch (error) {
      console.error('Pet updated, but the previous image could not be removed:', error);
      req.flash('warning', 'Pet details were saved, but the previous image could not be removed.');
    }
  }
  req.flash('success', `${values.name}'s profile has been updated.`);
  return res.redirect(`/journals?petId=${encodeURIComponent(pet.id)}`);
}

async function deletePet(req, res) {
  const pet = req.pet;
  try {
    const deleted = await Pet.deleteForOwner(pet.id, req.session.user.id);
    if (!deleted) return res.status(404).send('Pet not found.');
  } catch (error) {
    console.error('Error deleting pet:', error);
    req.flash('error', 'We could not delete this pet right now. Please try again.');
    return res.redirect('/journals');
  }

  try {
    await deleteImageIfUnused(pet.image);
  } catch (error) {
    console.error('Pet deleted, but its image could not be removed:', error);
    req.flash('warning', 'Pet and journal entries were deleted, but its image could not be removed.');
    return res.redirect('/journals');
  }

  req.flash('success', `${pet.name} and its journal entries have been deleted.`);
  return res.redirect('/journals');
}

module.exports = { showNewPet, createPet, showEditPet, updatePet, deletePet };
