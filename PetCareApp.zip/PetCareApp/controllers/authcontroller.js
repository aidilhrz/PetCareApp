const User = require('../models/userModel');
const { hashPassword, verifyPassword } = require('../helpers/passwordHelper');
const { validateSignup, PASSWORD_MIN_LENGTH, PASSWORD_MAX_LENGTH } = require('../helpers/signupValidation');

function showSignup(req, res) {
  res.render('signUp', {
    session: req.session,
    errors: req.flash('error'),
    form: {},
    passwordMinLength: PASSWORD_MIN_LENGTH,
    passwordMaxLength: PASSWORD_MAX_LENGTH
  });
}

async function signup(req, res) {
  const { values, errors } = validateSignup(req.body);
  const renderSignup = (statusCode, messages) => res.status(statusCode).render('signUp', {
    session: req.session,
    errors: messages,
    form: values,
    passwordMinLength: PASSWORD_MIN_LENGTH,
    passwordMaxLength: PASSWORD_MAX_LENGTH
  });

  if (errors.length > 0) return renderSignup(400, errors);

  try {
    const passwordHash = await hashPassword(values.password);
    await User.createWithPet({
      username: values.username,
      password: passwordHash,
      name: values.name,
      role: 'user'
    }, {
      name: values.petName,
      species: values.species,
      breed: values.breed,
      age: values.age,
      image: req.file ? req.file.filename : null
    });
    req.flash('success', 'Your account is ready. You can now log in.');
    res.redirect('/login');
  } catch (error) {
    if (error.code === 'ER_DUP_ENTRY') {
      return renderSignup(409, ['That username is already taken. Please choose another.']);
    }
    console.error('Error creating account and pet:', error);
    return renderSignup(500, ['We could not create your account right now. Please try again.']);
  }
}

function showLogin(req, res) {
  res.render('login', {
    messages: req.flash('success'),
    errors: req.flash('error'),
    session: req.session
  });
}

async function login(req, res) {
  const username = typeof req.body.username === 'string' ? req.body.username.trim() : '';
  const password = typeof req.body.password === 'string' ? req.body.password : '';

  if (!username || !password) {
    req.flash('error', 'Enter both your username and password.');
    return res.redirect('/login');
  }

  try {
    const user = await User.findByUsername(username);
    if (!user) {
      req.flash('error', 'Invalid username or password.');
      return res.redirect('/login');
    }

    const verification = await verifyPassword(password, user.password);
    if (!verification.valid) {
      req.flash('error', 'Invalid username or password.');
      return res.redirect('/login');
    }

    if (verification.needsRehash) {
      await User.updatePasswordHash(user.id, await hashPassword(password));
    }

    const sessionUser = {
      id: user.id,
      username: user.username,
      name: user.name,
      role: user.role
    };

    req.session.regenerate((error) => {
      if (error) {
        console.error('Login session regeneration error:', error);
        return res.status(500).send('Unable to log in. Please try again.');
      }

      req.session.user = sessionUser;
      req.flash('success', 'Login successful!');
      req.session.save((saveError) => {
        if (saveError) {
          console.error('Login session save error:', saveError);
          return res.status(500).send('Unable to log in. Please try again.');
        }
        if (user.role === 'admin') return res.redirect('/admin/dashboard');
        return res.redirect('/journals');
      });
    });
  } catch (error) {
    console.error('Login error:', error);
    req.flash('error', 'Unable to log in right now. Please try again.');
    res.redirect('/login');
  }
}

function logout(req, res) {
  req.session.destroy((error) => {
    if (error) {
      console.error('Logout session error:', error);
      return res.status(500).send('Unable to log out.');
    }
    res.redirect('/login');
  });
}

module.exports = {
  showSignup,
  signup,
  showLogin,
  login,
  logout,
  PASSWORD_MIN_LENGTH,
  PASSWORD_MAX_LENGTH
};
