const User = require('../models/userModel');
const Pet = require('../models/petModel');

async function dashboard(req, res) {
  res.render('adminDashboard', { session: req.session });
}

async function listUsers(req, res) {
  try {
    const users = await User.findAll();
    res.render('adminUsers', {
      users,
      session: req.session,
      messages: req.flash('success'),
      errors: req.flash('error')
    });
  } catch (error) {
    console.error('Error loading users:', error);
    res.status(500).send('Error loading users');
  }
}

async function userDetails(req, res) {
  try {
    const user = await User.findById(req.params.id);
    if (!user) return res.status(404).send('User not found');

    const [pets, journals] = await Promise.all([
      Pet.findByOwnerId(req.params.id),
      Pet.findJournalsByOwner(req.params.id)
    ]);

    res.render('adminUserDetails', {
      user,
      pets,
      journals,
      session: req.session
    });
  } catch (error) {
    console.error('Error retrieving user details:', error);
    res.status(500).send('Error retrieving user details');
  }
}

async function deleteUser(req, res) {
  try {
    await User.deleteById(req.params.id);
    res.redirect('/admin/users');
  } catch (error) {
    console.error('Error deleting user:', error);
    res.status(500).send('Error deleting user');
  }
}

async function updateUserRole(req, res) {
  const userId = Number(req.params.id);
  const { role } = req.body;

  if (!Number.isInteger(userId) || userId < 1 || !['admin', 'user'].includes(role)) {
    req.flash('error', 'Invalid user or role.');
    return res.redirect('/admin/users');
  }
  if (userId === req.session.user.id && role !== 'admin') {
    req.flash('error', 'You cannot remove your own administrator access.');
    return res.redirect('/admin/users');
  }

  try {
    const updated = await User.updateRole(userId, role);
    req.flash(updated ? 'success' : 'error', updated ? 'User role updated.' : 'User not found.');
    return res.redirect('/admin/users');
  } catch (error) {
    console.error('Error updating user role:', error);
    req.flash('error', 'Unable to update the user role right now.');
    return res.redirect('/admin/users');
  }
}

module.exports = { dashboard, listUsers, userDetails, deleteUser, updateUserRole };
