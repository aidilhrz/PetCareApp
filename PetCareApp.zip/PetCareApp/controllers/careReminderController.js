const Pet = require('../models/petModel');
const CareReminder = require('../models/careReminderModel');
const { validateCareReminder } = require('../helpers/careReminderValidation');

async function listCareReminders(req, res) {
  try {
    const [pets, reminders] = await Promise.all([
      Pet.findByOwner(req.session.user.id),
      CareReminder.findByOwner(req.session.user.id)
    ]);
    res.render('careReminders', {
      pets,
      overdueReminders: reminders.filter(reminder => Number(reminder.overdue) === 1),
      upcomingReminders: reminders.filter(reminder => Number(reminder.overdue) === 0),
      session: req.session,
      messages: req.flash('success'),
      errors: req.flash('error')
    });
  } catch (error) {
    console.error('Error loading care reminders:', error);
    res.status(500).send('Error loading care reminders.');
  }
}

async function showNewCareReminder(req, res) {
  try {
    const pets = await Pet.findByOwner(req.session.user.id);
    res.render('newCareReminder', {
      pets,
      errors: [],
      form: { pet_id: req.query.petId || '', type: '', title: '', due_date: '', notes: '' },
      session: req.session
    });
  } catch (error) {
    console.error('Error loading pets for care reminder form:', error);
    res.status(500).send('Error loading pets.');
  }
}

async function createCareReminder(req, res) {
  const { values, errors } = validateCareReminder(req.body);

  try {
    const pets = await Pet.findByOwner(req.session.user.id);
    if (errors.length > 0) {
      return res.status(400).render('newCareReminder', {
        pets,
        errors,
        form: req.body,
        session: req.session
      });
    }

    const created = await CareReminder.createForOwner(req.session.user.id, values);
    if (!created) return res.status(404).send('Pet not found.');

    req.flash('success', 'Care reminder added.');
    return res.redirect('/care-reminders');
  } catch (error) {
    console.error('Error saving care reminder:', error);
    res.status(500).send('Error saving care reminder.');
  }
}

async function deleteCareReminder(req, res) {
  try {
    const deleted = await CareReminder.deleteForOwner(req.session.user.id, req.params.id);
    if (!deleted) return res.status(404).send('Care reminder not found.');

    req.flash('success', 'Care reminder deleted.');
    return res.redirect('/care-reminders');
  } catch (error) {
    console.error('Error deleting care reminder:', error);
    res.status(500).send('Error deleting care reminder.');
  }
}

module.exports = {
  listCareReminders,
  showNewCareReminder,
  createCareReminder,
  deleteCareReminder
};
