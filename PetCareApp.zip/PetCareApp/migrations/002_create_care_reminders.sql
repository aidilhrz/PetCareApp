CREATE TABLE care_reminders (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  pet_id INT UNSIGNED NOT NULL,
  type ENUM('vaccination', 'medication', 'vet_visit') NOT NULL,
  title VARCHAR(120) NOT NULL,
  due_date DATE NOT NULL,
  notes TEXT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_care_reminders_pet_due_date (pet_id, due_date),
  CONSTRAINT fk_care_reminders_pet
    FOREIGN KEY (pet_id) REFERENCES pets(id)
    ON DELETE CASCADE
    ON UPDATE CASCADE
) ENGINE=InnoDB;
