const test = require('node:test');
const assert = require('node:assert/strict');
const crypto = require('node:crypto');
const { hashPassword, verifyPassword } = require('../helpers/passwordHelper');
const { PASSWORD_MIN_LENGTH, PASSWORD_MAX_LENGTH, validateSignup } = require('../helpers/signupValidation');
const User = require('../models/userModel');
const { signup } = require('../controllers/authcontroller');

function validSignup(overrides = {}) {
  return {
    username: 'pet.owner',
    password: 'a-long-unique-passphrase',
    confirm_password: 'a-long-unique-passphrase',
    name: 'Pet Owner',
    pet_name: 'Mochi',
    species: 'Dog',
    breed: 'Maltese',
    age: '2',
    ...overrides
  };
}

test('signup accepts valid account and pet details', () => {
  const { errors, values } = validateSignup(validSignup());
  assert.deepEqual(errors, []);
  assert.equal(values.username, 'pet.owner');
  assert.equal(values.age, 2);
});

test('signup always creates a standard user even if a role is submitted', async () => {
  const originalCreateWithPet = User.createWithPet;
  let createdUser;
  let redirectPath;
  User.createWithPet = async (user) => {
    createdUser = user;
  };

  try {
    await signup({
      body: validSignup({ role: 'admin' }),
      flash() {}
    }, {
      status() { return this; },
      render() {},
      redirect(path) { redirectPath = path; }
    });
  } finally {
    User.createWithPet = originalCreateWithPet;
  }

  assert.equal(createdUser.role, 'user');
  assert.equal(redirectPath, '/login');
});

test('signup rejects short passwords and mismatched confirmation', () => {
  const { errors } = validateSignup(validSignup({
    password: 'short',
    confirm_password: 'different'
  }));
  assert.ok(errors.some((error) => error.includes(`${PASSWORD_MIN_LENGTH}`)));
  assert.ok(errors.includes('Passwords do not match.'));
});

test('signup enforces username and pet age constraints', () => {
  const { errors } = validateSignup(validSignup({
    username: 'bad username',
    age: '256'
  }));
  assert.ok(errors.some((error) => error.includes('Username')));
  assert.ok(errors.some((error) => error.includes('age')));
});

test('password hashes are salted and verify correctly', async () => {
  const password = 'a-long-unique-passphrase';
  const firstHash = await hashPassword(password);
  const secondHash = await hashPassword(password);

  assert.notEqual(firstHash, secondHash);
  assert.ok(firstHash.length <= 255);
  assert.deepEqual(await verifyPassword(password, firstHash), {
    valid: true,
    needsRehash: false
  });
  assert.deepEqual(await verifyPassword('wrong-password', firstHash), {
    valid: false,
    needsRehash: false
  });
});

test('legacy SHA-256 passwords remain valid and are marked for rehash', async () => {
  const password = 'old-password';
  const legacyHash = crypto.createHash('sha256').update(password).digest('hex');

  assert.deepEqual(await verifyPassword(password, legacyHash), {
    valid: true,
    needsRehash: true
  });
  assert.deepEqual(await verifyPassword('incorrect', legacyHash), {
    valid: false,
    needsRehash: true
  });
});

test('password policy length bounds are exported', () => {
  assert.equal(PASSWORD_MIN_LENGTH, 12);
  assert.equal(PASSWORD_MAX_LENGTH, 128);
});
