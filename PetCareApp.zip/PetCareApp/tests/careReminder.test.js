const test = require('node:test');
const assert = require('node:assert/strict');
const { validateCareReminder } = require('../helpers/careReminderValidation');

function validReminder(overrides = {}) {
  return {
    pet_id: '12',
    type: 'vaccination',
    title: 'Annual booster',
    due_date: '2027-03-15',
    notes: 'Bring the vaccination record.',
    ...overrides
  };
}

test('care reminder validation accepts and normalizes a valid reminder', () => {
  const { values, errors } = validateCareReminder(validReminder({
    title: '  Annual booster  ',
    notes: '  Bring the record.  '
  }));
  assert.deepEqual(errors, []);
  assert.equal(values.petId, 12);
  assert.equal(values.title, 'Annual booster');
  assert.equal(values.notes, 'Bring the record.');
});

test('care reminder validation rejects invalid types, pet IDs, and impossible dates', () => {
  const { errors } = validateCareReminder(validReminder({
    pet_id: '12abc',
    type: 'grooming',
    due_date: '2027-02-29'
  }));
  assert.ok(errors.includes('Select a valid pet.'));
  assert.ok(errors.includes('Select a valid reminder type.'));
  assert.ok(errors.includes('Enter a valid due date.'));
});

test('care reminder validation enforces title and notes limits', () => {
  const { errors } = validateCareReminder(validReminder({
    title: 'x'.repeat(121),
    notes: 'x'.repeat(5001)
  }));
  assert.ok(errors.includes('Reminder title must be 120 characters or fewer.'));
  assert.ok(errors.includes('Notes must be 5,000 characters or fewer.'));
});
