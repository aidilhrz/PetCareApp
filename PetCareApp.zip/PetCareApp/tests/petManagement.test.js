const test = require('node:test');
const assert = require('node:assert/strict');
const { validatePet } = require('../helpers/petValidation');
const Pet = require('../models/petModel');
const { requireOwnedPet } = require('../middleware/petMiddleware');

function validPet(overrides = {}) {
  return {
    pet_name: 'Mochi',
    species: 'Dog',
    breed: 'Maltese',
    age: '2',
    ...overrides
  };
}

test('pet validation accepts a valid profile and normalizes its values', () => {
  const { values, errors } = validatePet(validPet({
    pet_name: '  Mochi  ',
    species: ' Dog ',
    age: '0'
  }));
  assert.deepEqual(errors, []);
  assert.equal(values.name, 'Mochi');
  assert.equal(values.species, 'Dog');
  assert.equal(values.age, 0);
});

test('pet validation rejects missing details and unsupported ages', () => {
  const { errors } = validatePet(validPet({
    pet_name: ' ',
    species: '',
    breed: 'x'.repeat(81),
    age: '2.5'
  }));
  assert.ok(errors.some((error) => error.includes('Pet name')));
  assert.ok(errors.some((error) => error.includes('Species')));
  assert.ok(errors.some((error) => error.includes('Breed')));
  assert.ok(errors.some((error) => error.includes('age')));
});

test('pet ownership middleware only continues for a pet owned by the session user', async () => {
  const originalFindByIdForOwner = Pet.findByIdForOwner;
  const requested = [];
  let continued = false;
  let responseStatus;
  let responseMessage;
  Pet.findByIdForOwner = async (petId, ownerId) => {
    requested.push([petId, ownerId]);
    return null;
  };

  try {
    await requireOwnedPet(
      { params: { id: '7' }, session: { user: { id: 21 } } },
      {
        status(status) { responseStatus = status; return this; },
        send(message) { responseMessage = message; }
      },
      () => { continued = true; }
    );
  } finally {
    Pet.findByIdForOwner = originalFindByIdForOwner;
  }

  assert.deepEqual(requested, [[7, 21]]);
  assert.equal(continued, false);
  assert.equal(responseStatus, 404);
  assert.equal(responseMessage, 'Pet not found.');
});
