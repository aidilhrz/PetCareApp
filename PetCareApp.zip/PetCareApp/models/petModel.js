const pool = require('./database');

async function findByOwner(ownerId) {
  const [rows] = await pool.execute('SELECT * FROM pets WHERE owner_id = ?', [ownerId]);
  return rows;
}

async function create(pet) {
  const [result] = await pool.execute(
    'INSERT INTO pets (owner_id, name, species, breed, age, image) VALUES (?, ?, ?, ?, ?, ?)',
    [pet.ownerId, pet.name, pet.species, pet.breed, pet.age, pet.image]
  );
  return result.insertId;
}

async function findByIdForOwner(petId, ownerId) {
  const [rows] = await pool.execute(
    'SELECT * FROM pets WHERE id = ? AND owner_id = ?',
    [petId, ownerId]
  );
  return rows[0] || null;
}

async function updateForOwner(petId, ownerId, pet) {
  const [result] = await pool.execute(
    `UPDATE pets
     SET name = ?, species = ?, breed = ?, age = ?, image = ?
     WHERE id = ? AND owner_id = ?`,
    [pet.name, pet.species, pet.breed, pet.age, pet.image, petId, ownerId]
  );
  if (result.affectedRows > 0) return true;

  const existingPet = await findByIdForOwner(petId, ownerId);
  return existingPet !== null;
}

async function deleteForOwner(petId, ownerId) {
  const [result] = await pool.execute(
    'DELETE FROM pets WHERE id = ? AND owner_id = ?',
    [petId, ownerId]
  );
  return result.affectedRows > 0;
}

async function countByImage(image) {
  const [rows] = await pool.execute(
    'SELECT COUNT(*) AS count FROM pets WHERE image = ?',
    [image]
  );
  return Number(rows[0].count);
}

async function findByOwnerId(ownerId) {
  return findByOwner(ownerId);
}

async function findJournalsByOwner(ownerId) {
  const [rows] = await pool.execute(
    `SELECT journal.*, pets.id AS pet_id
     FROM journal
     JOIN pets ON journal.pet_id = pets.id
     WHERE pets.owner_id = ?`,
    [ownerId]
  );
  return rows;
}

module.exports = {
  findByOwner,
  findByOwnerId,
  findJournalsByOwner,
  findByIdForOwner,
  create,
  updateForOwner,
  deleteForOwner,
  countByImage
};
