const pool = require('./database');

async function findByOwner(ownerId) {
  const [rows] = await pool.execute(
    `SELECT care_reminders.id, care_reminders.pet_id, pets.name AS pet_name,
            care_reminders.type, care_reminders.title,
            DATE_FORMAT(care_reminders.due_date, '%Y-%m-%d') AS due_date,
            care_reminders.notes,
            CASE WHEN care_reminders.due_date < CURRENT_DATE() THEN 1 ELSE 0 END AS overdue
     FROM care_reminders
     JOIN pets ON pets.id = care_reminders.pet_id
     WHERE pets.owner_id = ?
     ORDER BY care_reminders.due_date ASC, care_reminders.id ASC`,
    [ownerId]
  );
  return rows;
}

async function createForOwner(ownerId, reminder) {
  const [result] = await pool.execute(
    `INSERT INTO care_reminders (pet_id, type, title, due_date, notes)
     SELECT pets.id, ?, ?, ?, ?
     FROM pets
     WHERE pets.id = ? AND pets.owner_id = ?`,
    [
      reminder.type,
      reminder.title,
      reminder.dueDate,
      reminder.notes || null,
      reminder.petId,
      ownerId
    ]
  );
  return result.affectedRows > 0;
}

async function deleteForOwner(ownerId, reminderId) {
  const [result] = await pool.execute(
    `DELETE care_reminders FROM care_reminders
     JOIN pets ON pets.id = care_reminders.pet_id
     WHERE care_reminders.id = ? AND pets.owner_id = ?`,
    [reminderId, ownerId]
  );
  return result.affectedRows > 0;
}

module.exports = { findByOwner, createForOwner, deleteForOwner };
