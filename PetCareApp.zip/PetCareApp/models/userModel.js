const pool = require('./database');

async function createWithPet(user, pet) {
  const connection = await pool.getConnection();
  try {
    await connection.beginTransaction();
    const [userResult] = await connection.execute(
      'INSERT INTO users (username, password, name, role) VALUES (?, ?, ?, ?)',
      [user.username, user.password, user.name, user.role]
    );
    await connection.execute(
      'INSERT INTO pets (owner_id, name, species, breed, age, image) VALUES (?, ?, ?, ?, ?, ?)',
      [userResult.insertId, pet.name, pet.species, pet.breed, pet.age, pet.image]
    );
    await connection.commit();
    return userResult.insertId;
  } catch (error) {
    await connection.rollback();
    throw error;
  } finally {
    connection.release();
  }
}

async function findByUsername(username) {
  const [rows] = await pool.execute(
    'SELECT id, username, password, name, role FROM users WHERE username = ?',
    [username]
  );
  return rows[0] || null;
}

async function updatePasswordHash(userId, passwordHash) {
  await pool.execute('UPDATE users SET password = ? WHERE id = ?', [passwordHash, userId]);
}

async function updateRole(userId, role) {
  const [result] = await pool.execute(
    'UPDATE users SET role = ? WHERE id = ?',
    [role, userId]
  );
  if (result.affectedRows > 0) return true;

  const [rows] = await pool.execute('SELECT id FROM users WHERE id = ?', [userId]);
  return rows.length > 0;
}

async function findAll() {
  const [rows] = await pool.execute('SELECT id, name, username, role FROM users');
  return rows;
}

async function findById(userId) {
  const [rows] = await pool.execute(
    'SELECT id, name, username, role FROM users WHERE id = ?',
    [userId]
  );
  return rows[0] || null;
}

async function deleteById(userId) {
  const [result] = await pool.execute('DELETE FROM users WHERE id = ?', [userId]);
  return result.affectedRows > 0;
}

module.exports = {
  createWithPet,
  findByUsername,
  updatePasswordHash,
  updateRole,
  findAll,
  findById,
  deleteById
};
