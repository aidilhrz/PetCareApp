const pool = require('./database');

async function findByOwnerAndPet(ownerId, petId) {
  const [rows] = await pool.execute(
    `SELECT journal.*, pets.name, pets.species, pets.breed, pets.age, pets.image
     FROM journal
     JOIN pets ON journal.pet_id = pets.id
     WHERE pets.owner_id = ? AND pets.id = ?`,
    [ownerId, petId]
  );
  return rows;
}

async function findByIdForOwner(journalId, ownerId) {
  const [rows] = await pool.execute(
    `SELECT journal.*
     FROM journal
     JOIN pets ON journal.pet_id = pets.id
     WHERE journal.id = ? AND pets.owner_id = ?`,
    [journalId, ownerId]
  );
  return rows[0] || null;
}

async function createForOwner(ownerId, journal) {
  const [result] = await pool.execute(
    `INSERT INTO journal (pet_id, activity, notes, entry_date)
     SELECT pets.id, ?, ?, ?
     FROM pets
     WHERE pets.id = ? AND pets.owner_id = ?`,
    [journal.activity, journal.notes, journal.entryDate, journal.petId, ownerId]
  );
  return result.affectedRows > 0;
}

async function updateForOwner(ownerId, journalId, journal) {
  const [result] = await pool.execute(
    `UPDATE journal
     SET entry_date = ?, activity = ?, notes = ?, pet_id = ?
     WHERE id = ?
       AND EXISTS (
         SELECT 1 FROM pets AS currentPet
         WHERE currentPet.id = journal.pet_id AND currentPet.owner_id = ?
       )
       AND EXISTS (
         SELECT 1 FROM pets AS targetPet
         WHERE targetPet.id = ? AND targetPet.owner_id = ?
       )`,
    [
      journal.entryDate,
      journal.activity,
      journal.notes,
      journal.petId,
      journalId,
      ownerId,
      journal.petId,
      ownerId
    ]
  );
  if (result.affectedRows > 0) return true;

  const [rows] = await pool.execute(
    `SELECT journal.id
     FROM journal
     JOIN pets ON journal.pet_id = pets.id
     WHERE journal.id = ? AND journal.pet_id = ? AND pets.owner_id = ?`,
    [journalId, journal.petId, ownerId]
  );
  return rows.length > 0;
}

async function deleteForOwner(ownerId, journalId) {
  const [result] = await pool.execute(
    `DELETE journal FROM journal
     JOIN pets ON journal.pet_id = pets.id
     WHERE journal.id = ? AND pets.owner_id = ?`,
    [journalId, ownerId]
  );
  return result.affectedRows > 0;
}

async function searchForOwner(ownerId, query, petId) {
  let sql = `
    SELECT journal.*, pets.name, pets.species, pets.breed, pets.age, pets.image
    FROM journal
    JOIN pets ON journal.pet_id = pets.id
    WHERE pets.owner_id = ? AND (journal.activity LIKE ? OR journal.notes LIKE ?)`;
  const params = [ownerId, query, query];

  if (petId) {
    sql += ' AND pets.id = ?';
    params.push(petId);
  }

  const [rows] = await pool.execute(sql, params);
  return rows;
}

module.exports = {
  findByOwnerAndPet,
  findByIdForOwner,
  createForOwner,
  updateForOwner,
  deleteForOwner,
  searchForOwner
};
