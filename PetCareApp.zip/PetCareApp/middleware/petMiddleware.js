const Pet = require('../models/petModel');

async function requireOwnedPet(req, res, next) {
  const petId = Number(req.params.id);
  if (!Number.isInteger(petId) || petId < 1) {
    return res.status(404).send('Pet not found.');
  }

  try {
    const pet = await Pet.findByIdForOwner(petId, req.session.user.id);
    if (!pet) return res.status(404).send('Pet not found.');
    req.pet = pet;
    return next();
  } catch (error) {
    console.error('Error checking pet ownership:', error);
    return res.status(500).send('Unable to load pet.');
  }
}

module.exports = { requireOwnedPet };
