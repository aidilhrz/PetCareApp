const path = require('path');
const multer = require('multer');
const crypto = require('crypto');

const imageDirectory = path.join(__dirname, '..', 'public', 'images');
const allowedTypes = new Map([
  ['image/jpeg', '.jpg'],
  ['image/png', '.png'],
  ['image/webp', '.webp'],
  ['image/gif', '.gif']
]);

const storage = multer.diskStorage({
  destination: (req, file, callback) => callback(null, imageDirectory),
  filename: (req, file, callback) => {
    const extension = allowedTypes.get(file.mimetype);
    callback(null, `${Date.now()}_${crypto.randomUUID()}${extension}`);
  }
});

module.exports = multer({
  storage,
  limits: { fileSize: 5 * 1024 * 1024 },
  fileFilter: (req, file, callback) => {
    if (!allowedTypes.has(file.mimetype)) {
      return callback(new Error('Upload a JPEG, PNG, WebP, or GIF image.'));
    }
    return callback(null, true);
  }
});
