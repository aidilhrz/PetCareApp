const express = require('express');
const careReminderController = require('../controllers/careReminderController');
const { requireLoggedIn } = require('../middleware/authMiddleware');

const router = express.Router();

router.use(requireLoggedIn);
router.get('/', careReminderController.listCareReminders);
router.get('/new', careReminderController.showNewCareReminder);
router.post('/new', careReminderController.createCareReminder);
router.post('/:id/delete', careReminderController.deleteCareReminder);

module.exports = router;
