const express = require('express');
const journalController = require('../controllers/journalcontroller');
const { requireLoggedIn } = require('../middleware/authMiddleware');

const router = express.Router();

router.use(requireLoggedIn);
router.get('/', journalController.listJournals);
router.get('/new', journalController.showNewJournal);
router.post('/new', journalController.createJournal);
router.get('/edit/:id', journalController.showEditJournal);
router.post('/edit/:id', journalController.updateJournal);
router.get('/delete/:id', journalController.deleteJournal);
router.get('/search', journalController.searchJournals);

module.exports = router;
