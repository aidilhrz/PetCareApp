const express = require('express');
const adminController = require('../controllers/admincontroller');
const { requireAdmin } = require('../middleware/authMiddleware');

const router = express.Router();

router.use(requireAdmin);
router.get('/dashboard', adminController.dashboard);
router.get('/users', adminController.listUsers);
router.post('/users/:id/role', adminController.updateUserRole);
router.get('/users/delete/:id', adminController.deleteUser);
router.get('/users/:id', adminController.userDetails);

module.exports = router;
