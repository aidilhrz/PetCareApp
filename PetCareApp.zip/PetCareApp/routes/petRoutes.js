const express = require('express');
const petController = require('../controllers/petcontroller');
const upload = require('../helpers/uploadHelper');
const { requireLoggedIn } = require('../middleware/authMiddleware');
const { requireOwnedPet } = require('../middleware/petMiddleware');

const router = express.Router();

function handlePetImageUpload(req, res, next) {
  upload.single('pet_image')(req, res, (error) => {
    if (!error) return next();

    console.error('Pet image upload error:', error);
    const message = error.code === 'LIMIT_FILE_SIZE'
      ? 'Pet images must be 5 MB or smaller.'
      : error.message;
    req.flash('error', message);
    return res.redirect(req.params.id ? `/pets/${req.params.id}/edit` : '/pets/new');
  });
}

router.get('/new', requireLoggedIn, petController.showNewPet);
router.post('/', requireLoggedIn, handlePetImageUpload, petController.createPet);
router.get('/:id/edit', requireLoggedIn, requireOwnedPet, petController.showEditPet);
router.post('/:id/edit', requireLoggedIn, requireOwnedPet, handlePetImageUpload, petController.updatePet);
router.post('/:id/delete', requireLoggedIn, requireOwnedPet, petController.deletePet);

module.exports = router;
