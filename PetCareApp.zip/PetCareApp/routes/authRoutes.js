const express = require('express');
const authController = require('../controllers/authcontroller');
const upload = require('../helpers/uploadHelper');

const router = express.Router();

router.get('/signup', authController.showSignup);
router.post('/signup', upload.single('pet_image'), authController.signup);
router.get('/login', authController.showLogin);
router.post('/login', authController.login);
router.get('/logout', authController.logout);

module.exports = router;
