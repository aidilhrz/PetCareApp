module.exports = require('../config/upload');
