const PASSWORD_MIN_LENGTH = 12;
const PASSWORD_MAX_LENGTH = 128;

function validateSignup(fields) {
  const values = {
    username: typeof fields.username === 'string' ? fields.username.trim() : '',
    password: typeof fields.password === 'string' ? fields.password : '',
    confirmPassword: typeof fields.confirm_password === 'string' ? fields.confirm_password : '',
    name: typeof fields.name === 'string' ? fields.name.trim() : '',
    petName: typeof fields.pet_name === 'string' ? fields.pet_name.trim() : '',
    species: typeof fields.species === 'string' ? fields.species.trim() : '',
    breed: typeof fields.breed === 'string' ? fields.breed.trim() : '',
    age: typeof fields.age === 'string' && fields.age.trim() !== '' ? Number(fields.age) : NaN
  };
  const errors = [];

  if (!/^[a-zA-Z0-9._-]{3,30}$/.test(values.username)) {
    errors.push('Username must be 3-30 characters and use only letters, numbers, dots, underscores, or hyphens.');
  }
  if (values.password.length < PASSWORD_MIN_LENGTH || values.password.length > PASSWORD_MAX_LENGTH) {
    errors.push(`Password must be between ${PASSWORD_MIN_LENGTH} and ${PASSWORD_MAX_LENGTH} characters.`);
  }
  if (values.password !== values.confirmPassword) {
    errors.push('Passwords do not match.');
  }
  if (!values.name || values.name.length > 100) {
    errors.push('Your name is required and must be 100 characters or fewer.');
  }
  if (!values.petName || values.petName.length > 80) {
    errors.push('Pet name is required and must be 80 characters or fewer.');
  }
  if (!values.species || values.species.length > 50) {
    errors.push('Species is required and must be 50 characters or fewer.');
  }
  if (!values.breed || values.breed.length > 80) {
    errors.push('Breed is required and must be 80 characters or fewer.');
  }
  if (!Number.isInteger(values.age) || values.age < 0 || values.age > 255) {
    errors.push('Pet age must be a whole number between 0 and 255.');
  }

  return { values, errors };
}

module.exports = { PASSWORD_MIN_LENGTH, PASSWORD_MAX_LENGTH, validateSignup };
