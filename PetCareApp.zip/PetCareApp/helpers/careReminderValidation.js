const REMINDER_TYPES = ['vaccination', 'medication', 'vet_visit'];

function isValidDate(value) {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(value)) return false;
  const [year, month, day] = value.split('-').map(Number);
  if (year < 1000 || year > 9999) return false;
  const date = new Date(Date.UTC(year, month - 1, day));
  return date.getUTCFullYear() === year
    && date.getUTCMonth() === month - 1
    && date.getUTCDate() === day;
}

function validateCareReminder(input) {
  const values = {
    petId: String(input.pet_id || '').trim(),
    type: String(input.type || '').trim(),
    title: String(input.title || '').trim(),
    dueDate: String(input.due_date || '').trim(),
    notes: String(input.notes || '').trim()
  };
  const errors = [];

  if (!/^[1-9]\d*$/.test(values.petId)) {
    errors.push('Select a valid pet.');
  } else {
    values.petId = Number(values.petId);
  }
  if (!REMINDER_TYPES.includes(values.type)) {
    errors.push('Select a valid reminder type.');
  }
  if (!values.title) {
    errors.push('Reminder title is required.');
  } else if (values.title.length > 120) {
    errors.push('Reminder title must be 120 characters or fewer.');
  }
  if (!isValidDate(values.dueDate)) {
    errors.push('Enter a valid due date.');
  }
  if (values.notes.length > 5000) {
    errors.push('Notes must be 5,000 characters or fewer.');
  }

  return { values, errors };
}

module.exports = { REMINDER_TYPES, validateCareReminder };
