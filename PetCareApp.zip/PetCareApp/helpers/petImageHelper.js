const fs = require('fs/promises');
const path = require('path');
const Pet = require('../models/petModel');

const imageDirectory = path.resolve(__dirname, '..', 'public', 'images');

async function deleteImageIfUnused(filename) {
  if (!filename) return;

  const imagePath = path.resolve(imageDirectory, filename);
  if (path.basename(filename) !== filename || path.dirname(imagePath) !== imageDirectory) {
    throw new Error('Refusing to delete an image outside the pet image directory.');
  }

  if (await Pet.countByImage(filename) > 0) return;

  try {
    await fs.unlink(imagePath);
  } catch (error) {
    if (error.code !== 'ENOENT') throw error;
  }
}

module.exports = { deleteImageIfUnused };
