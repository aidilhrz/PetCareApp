function validatePet(fields) {
  const values = {
    name: typeof fields.pet_name === 'string' ? fields.pet_name.trim() : '',
    species: typeof fields.species === 'string' ? fields.species.trim() : '',
    breed: typeof fields.breed === 'string' ? fields.breed.trim() : '',
    age: typeof fields.age === 'string' && fields.age.trim() !== '' ? Number(fields.age) : NaN
  };
  const errors = [];

  if (!values.name || values.name.length > 80) {
    errors.push('Pet name is required and must be 80 characters or fewer.');
  }
  if (!values.species || values.species.length > 50) {
    errors.push('Species is required and must be 50 characters or fewer.');
  }
  if (!values.breed || values.breed.length > 80) {
    errors.push('Breed is required and must be 80 characters or fewer.');
  }
  if (!Number.isInteger(values.age) || values.age < 0 || values.age > 255) {
    errors.push('Pet age must be a whole number between 0 and 255.');
  }

  return { values, errors };
}

module.exports = { validatePet };
