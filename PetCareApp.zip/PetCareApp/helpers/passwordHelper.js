const crypto = require('crypto');
const { promisify } = require('util');

const scrypt = promisify(crypto.scrypt);
const KEY_LENGTH = 64;
const SCRYPT_OPTIONS = { N: 16384, r: 8, p: 1 };

async function hashPassword(password) {
  const salt = crypto.randomBytes(16);
  const derivedKey = await scrypt(password, salt, KEY_LENGTH, SCRYPT_OPTIONS);
  return `scrypt$${salt.toString('hex')}$${derivedKey.toString('hex')}`;
}

async function verifyPassword(password, storedHash) {
  if (typeof storedHash !== 'string') return { valid: false, needsRehash: false };

  const [algorithm, saltHex, keyHex, extra] = storedHash.split('$');
  if (algorithm === 'scrypt' && saltHex && keyHex && !extra && /^[a-f\d]+$/i.test(saltHex) && /^[a-f\d]+$/i.test(keyHex)) {
    const salt = Buffer.from(saltHex, 'hex');
    const expectedKey = Buffer.from(keyHex, 'hex');
    if (salt.length !== 16 || expectedKey.length !== KEY_LENGTH) {
      return { valid: false, needsRehash: false };
    }

    const actualKey = await scrypt(password, salt, KEY_LENGTH, SCRYPT_OPTIONS);
    return {
      valid: crypto.timingSafeEqual(actualKey, expectedKey),
      needsRehash: false
    };
  }

  if (/^[a-f\d]{64}$/i.test(storedHash)) {
    const legacyHash = crypto.createHash('sha256').update(password).digest();
    const expectedHash = Buffer.from(storedHash, 'hex');
    return {
      valid: crypto.timingSafeEqual(legacyHash, expectedHash),
      needsRehash: true
    };
  }

  return { valid: false, needsRehash: false };
}

module.exports = { hashPassword, verifyPassword };
